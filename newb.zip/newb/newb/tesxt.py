for bullet in bullets:
    if bullet.y - bullet.radius < goblin2.hitbox[1] + goblin2.hitbox[3] and bullet.y + bullet.radius > \
            goblin2.hitbox[
                1]:
        if bullet.x + bullet.radius > goblin2.hitbox[0] and bullet.x - bullet.radius < goblin2.hitbox[0] + \
                goblin2.hitbox[2]:
            goblin2.hit()
            score += 1
            bullets.pop(bullets.index(bullet))